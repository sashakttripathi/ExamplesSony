﻿#pragma once
#include <commctrl.h>
#include <tchar.h>
#include <windows.h>

#include "resource.h"

class RemoteCtrlWin {
 public:
 protected:
 private:
};
