﻿#ifndef PTPTDEF
#define PTPTDEF
#include <windows.h>

#include <string>
#include <vector>

#define PTP_DT_UNDEF 0x0000
#define PTP_DT_INT8 0x0001
#define PTP_DT_UINT8 0x0002
#define PTP_DT_INT16 0x0003
#define PTP_DT_UINT16 0x0004
#define PTP_DT_INT32 0x0005
#define PTP_DT_UINT32 0x0006
#define PTP_DT_INT64 0x0007
#define PTP_DT_UINT64 0x0008
#define PTP_DT_INT128 0x0009
#define PTP_DT_UINT128 0x000A
#define PTP_DT_AINT8 0x4001
#define PTP_DT_AUINT8 0x4002
#define PTP_DT_AINT16 0x4003
#define PTP_DT_AUINT16 0x4004
#define PTP_DT_AINT32 0x4005
#define PTP_DT_AUINT32 0x4006
#define PTP_DT_AINT64 0x4007
#define PTP_DT_AUINT64 0x4008
#define PTP_DT_AINT128 0x4009
#define PTP_DT_AUINT128 0x400A
#define PTP_DT_STR 0xFFFF

#define PTP_RC_UNDEFINED 0x2000
#define PTP_RC_OK 0x2001

const DWORD SDI_Extension_Version = 0x12C;

const DWORD SHOT_OBJECT_HANDLE = 0xFFFFC001;

const DWORD ESCAPE_PTP_VENDOR_COMMAND = 0x0100;

const DWORD PTP_MAX_PARAMS = 5;

#pragma pack(push, Old, 1)

typedef struct _PTP_VENDOR_DATA_IN {
  WORD OpCode;
  DWORD SessionId;
  DWORD TransactionId;
  DWORD Params[PTP_MAX_PARAMS];
  DWORD NumParams;
  DWORD NextPhase;
  BYTE VendorWriteData[1];
} PTP_VENDOR_DATA_IN, *PPTP_VENDOR_DATA_IN;

typedef struct _PTP_VENDOR_DATA_OUT {
  WORD ResponseCode;
  DWORD SessionId;
  DWORD TransactionId;
  DWORD Params[PTP_MAX_PARAMS];
  BYTE VendorReadData[1];
} PTP_VENDOR_DATA_OUT, *PPTP_VENDOR_DATA_OUT;

#pragma pack(pop, Old)

const DWORD SIZEOF_REQUIRED_VENDOR_DATA_IN = sizeof(PTP_VENDOR_DATA_IN) - 1;
const DWORD SIZEOF_REQUIRED_VENDOR_DATA_OUT = sizeof(PTP_VENDOR_DATA_OUT) - 1;

const DWORD PTP_NEXTPHASE_READ_DATA = 3;
const DWORD PTP_NEXTPHASE_WRITE_DATA = 4;
const DWORD PTP_NEXTPHASE_NO_DATA = 5;

#pragma pack(1)
typedef struct _PTP_GetObjectInfo {
  DWORD StorageID;
  WORD ObjFormat;
  WORD Protect;
  DWORD ObjCompSz;
  WORD ThumFormat;
  DWORD ThumCompSz;
  BYTE ThumPixW[4];
  BYTE ThumPixH[4];
  BYTE ImgPixW[4];
  BYTE ImgPixH[4];
  BYTE ImgBitDep[4];
  BYTE ParObj[4];
  WORD AssType;
  DWORD AssDesc;
  DWORD SeqNum;
  BYTE FileNemeLen;
  BYTE FileName[27];
  BYTE CaptDate[32];
  BYTE ModDate;
  BYTE Keywords;
  BYTE dummy[32];
} PTP_GetObjectInfo, *PPTP_GetObjectInfo;
#pragma pack()

#pragma pack(1)
typedef struct _PTP_GetStorageInfo {
  WORD StorageType;
  WORD FileSystemType;
  WORD AccessCapabilities;
  DWORD MaxCapacity;
  DWORD FreeSpaceInBytes;
  WORD FreeSpaceInImages;

} PTP_GetStorageInfo, *PPTP_GetStorageInfo;
#pragma pack()

enum PTPOperationCode {
  PTP_OC_GetDeviceInfo = 0x1001,
  PTP_OC_GetStorageID = 0x1004,
  PTP_OC_GetStorageInfo = 0x1005,
  PTP_OC_GetNumObjects = 0x1006,
  PTP_OC_GetObjectHandles = 0x1007,
  PTP_OC_GetObjectInfo = 0x1008,
  PTP_OC_GetObject = 0x1009,
  PTP_OC_CloseSession = 0x1003,
  PTP_OC_DeleteObject = 0x100B,
};

enum SDIOOperationCode {
  PTP_OC_SDIOConnect = 0x9201,
  PTP_OC_SDIOGetExtDeviceInfo = 0x9202,
  PTP_OC_SDIOSetExtDevicePropValue = 0x9205,
  PTP_OC_SDIOControlDevice = 0x9207,
  PTP_OC_SDIOGetAllExtDeviceInfo = 0x9209,
  PTP_OC_SDIOSetContentsTransferMode = 0x9212,
};

enum DevicePropertiesCode {
  DPC_MOVIE_REC = 0xD2C8,
  DPC_S2_BUTTON = 0xD2C2,
  DPC_S1_BUTTON = 0xD2C1,
  DPC_AE_LOCK = 0xD2C3,
  DPC_AF_LOCK = 0xD2C9,
  DPC_LIVEVIEW_MODE = 0xD26A,
  DPC_DRIVE_MODE = 0x5013,
  DPC_ASPECT_RATIO = 0xD211,
  DPC_IMAGE_SIZE = 0xD203,
  DPC_WHITE_BALANCE = 0x5005,
  DPC_EXPOSURE_COMPENSATION = 0x5010,
  DPC_FNUMBER = 0x5007,
  DPC_SHOOTING_FILE_INFOMATION = 0xD215,
  DPC_FOCUS_MODE = 0x500A,
  DPC_EXPOSURE_MODE = 0x500E,
  DPC_DRO_HDR_MODE = 0xD201,
  DPC_FOCUS_AREA_X_Y = 0xD2DC,
  DPC_FOCUS_AREA = 0xD22C,
  DPC_LIVEVIEW_STATUS = 0xD221,
  DPC_SHUTTER_SPEED = 0xD20D,
  DPC_COLOR_TEMP = 0xD20F,
  DPC_ISO = 0xD21E,
  DPC_FLASH_MODE = 0x500C,
  DPC_METERING_MODE = 0x500B,
  DPC_PICTURE_EFFECTS = 0xD21B,
  DPC_BATTERY_LEVEL = 0xD20E,
  DPC_POSITION_KEY = 0xD25A,
  DPC_AELOCK_INDICATION = 0xD217,
  DPC_AFLOCK_INDICATION = 0xD21F,
  DPC_WHITEBALANCE_AB = 0xD21C,
  DPC_WHITEBALANCE_GM = 0xD210,
  DPC_COMPRESSION_SETTING = 0x5004,
  DPC_IMAGE_FILE_FORMAT = 0x5004,
  DPC_VIEW = 0xD231,
  DPC_FLASH_COMP = 0xD200,
  DPC_WIRELESS_FLASH = 0xD262,
  DPC_AWB_LOCK = 0xD2D9,
  DPC_NORMAL = 0xD2D4,
  DPC_AF_STATUS = 0xD213,
  DPC_PICTURE_PROFILE = 0xD23F,
  DPC_CREATIVE_STYLE = 0xD240,
  DPC_MOVIE_FORMAT = 0xD241,
  DPC_MOVIE_QUALITY = 0xD242,
  DPC_SAVE_MEDIA = 0xD222,
  DPC_ZOOM_SETTING = 0xD25F,
  DPC_ZOOM_SCALE = 0xD25C,
  DPC_ZOOM_OPTIC = 0xD25D,
  DPC_NEAR_FAR = 0xD2D1,
  DPC_ZOOM = 0xD2DD,
  DPC_MEDIA_FORMAT = 0xD2CA,
  DPC_JPEG_QUALITY = 0xD252,
  DPC_FILE_FORMAT = 0xD253,
  DPC_FOCUS_MAGNIFY = 0xD254,
};

#endif
